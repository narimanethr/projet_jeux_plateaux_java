package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPlateauGuerre {

	@Test
	void test() {
		
	}

}
